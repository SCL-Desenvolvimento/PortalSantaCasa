import { Component } from '@angular/core';

@Component({
  selector: 'app-word-search-game',
  standalone: false,
  templateUrl: './word-search-game.component.html',
  styleUrl: './word-search-game.component.css'
})
export class WordSearchGameComponent { }
